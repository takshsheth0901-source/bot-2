# Gold Trading Bot - OANDA version (runs on GitHub Actions, free, 2 secrets only)

Trades spot gold (XAU/USD) directly on OANDA through their REST v20 API.
Runs automatically every 15 minutes via GitHub Actions - nothing needs to
stay open on your computer, and it's free indefinitely on a public repo.

## The only 2 things you need to set up

1. `OANDA_API_TOKEN` (Secret) - your personal access token
2. `OANDA_ACCOUNT_ID` (Secret) - looks like `101-004-40390415-001`

No ticker lookup needed this time - gold's ticker on OANDA is always
`XAU_USD`, already set in the code.

## Setup (all through github.com in your browser)

1. **Create a GitHub repository** (Public, no README needed).

2. **Upload files**: "Add file" -> "Upload files" -> drag in `bot.py` and
   the `.github` folder (containing `workflows/trading-bot.yml`). Commit.

3. **Add the 2 Secrets**: repo -> Settings -> Secrets and variables ->
   Actions -> "New repository secret":
   - `OANDA_API_TOKEN` = the token you generated in OANDA (Tools -> API -> Generate)
   - `OANDA_ACCOUNT_ID` = your account ID (shown in the Accounts panel, e.g. `101-004-40390415-001`)

4. **Run it once manually**: Actions tab -> "Gold Trading Bot (OANDA)" ->
   "Run workflow" (twice to confirm). Check the run log to make sure it
   completes without an ERROR line.

5. **Done.** It now runs every 15 minutes automatically, for free,
   forever, on your OANDA demo account.

## Checking on it

- **Actions tab**: every run, success or error.
- **bot_activity.csv** in your repo: updates itself after each run -
  decision, score, account equity (NAV), action taken.
- **To pause it**: add a file called `STOP` to the repo. Delete it to resume.

## Important notes specific to OANDA

- Gold is quoted and traded here as **XAU/USD** - "units" in the code
  correspond to ounces of gold, not shares.
- OANDA's demo account needs no ID/passport verification - only a live
  account requires that, and this bot only trades demo by default
  (`USE_DEMO_ACCOUNT = True` at the top of `bot.py`).
- Real-money leverage/margin rules apply differently to CFDs like gold
  than they do to buying shares outright - read up on how margin works
  on OANDA before ever considering live trading with this.

## Going live

Only after watching `bot_activity.csv` for a good stretch: open a live
OANDA account (this does require ID verification), generate a **live**
API token, update the two Secrets with live values, then open `bot.py`,
change `USE_DEMO_ACCOUNT = True` to `False` near the top, and re-upload.
